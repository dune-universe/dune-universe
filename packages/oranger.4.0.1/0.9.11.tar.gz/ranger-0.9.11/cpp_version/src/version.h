#ifndef RANGER_VERSION
#define RANGER_VERSION "0.9.11"
#endif
